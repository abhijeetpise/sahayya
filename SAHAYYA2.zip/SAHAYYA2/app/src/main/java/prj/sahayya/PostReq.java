package prj.sahayya;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

public class PostReq extends AppCompatActivity implements AdapterView.OnItemSelectedListener,MultiSelectionSpinner.OnMultipleItemsSelectedListener{
  Button b1,b2;
    String[] country = { "INDIA", "USA", "UK", "RUSSIA" };
    String[] state = { "Maharashtra", "Gujarat", "Karnatak", "Uttarpradesh" };
    String[] city = { "Ratnagiri","Pune", "Mumbai", "Nashik","Nagpur" };
    String[] urgency = { "Low", "Medium", "High", "Critical" };
    Spinner spin3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_req);

       b2 =(Button)findViewById(R.id.button5);
      b1=(Button)findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomDialog();

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(PostReq.this, Upload.class);
                startActivity(i);
            }
        });
         spin3 = (Spinner)findViewById(R.id.spinner4);
        spin3.setOnItemSelectedListener(this);
        ArrayAdapter aa3 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, urgency);
        aa3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin3.setAdapter(aa3);




        String[] array = {"Medical",        //category
                "Transport",
                "Fire",
                "Agriculture",
                "Natural Disaster",
                "Telecommunication ",
                "Education"};
        MultiSelectionSpinner multiSelectionSpinner =(MultiSelectionSpinner)findViewById(R.id.spinner3);
        multiSelectionSpinner.setItems(array);
        multiSelectionSpinner.setSelection(new int[]{2, 6});
        multiSelectionSpinner.setListener(this);
    }


    protected void showCustomDialog() {
        // TODO Auto-generated method stub
        final Dialog dialog = new Dialog(PostReq.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.setContentView(R.layout.dialog);

        final Spinner spin = (Spinner) dialog.findViewById(R.id.spinner);
        final Spinner spin1 = (Spinner) dialog.findViewById(R.id.spinner5);
        final Spinner spin2 = (Spinner) dialog.findViewById(R.id.spinner2);

        spin.setOnItemSelectedListener(this);
        spin1.setOnItemSelectedListener(this);
        spin2.setOnItemSelectedListener(this);

        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, country);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayAdapter aa1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, state);
        aa1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayAdapter aa2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, city);
        aa2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //Setting the ArrayAdapter data on the Spinner
        spin.setAdapter(aa);
        spin1.setAdapter(aa1);
        spin2.setAdapter(aa2);

        Button button = (Button) dialog.findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //_textDialog.setText(editText.getText().toString());
                dialog.dismiss();
            }
        });

        dialog.show();
    }
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        //Toast.makeText(getApplicationContext(),country[position] ,Toast.LENGTH_LONG).show();
    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }
    public void selectedIndices(List<Integer> indices) {

    }

    @Override
    public void selectedStrings(List<String> strings) {
        //Toast.makeText(this, strings.toString(), Toast.LENGTH_LONG).show();
    }

}
