package prj.sahayya;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.widget.Button;
import android.widget.ImageView;
import android.view.View;
import android.content.Intent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import android.graphics.Bitmap;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.BitmapFactory;
import android.util.Log;



public class Upload extends AppCompatActivity {
    public final int CAMERA_REQUEST = 10;
    Bitmap camera_picture = null;
    File f;
    ImageView image;
    FileOutputStream fos;
    ByteArrayOutputStream baos = null;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);


        FloatingActionButton camera = (FloatingActionButton) findViewById(R.id.camera);  ///image
        image = (ImageView) findViewById(R.id.image);

        //product_description_layout = (LinearLayout) findViewById(R.id.product_description_layout);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(i, CAMERA_REQUEST);
            }
        });

        b1=(Button)findViewById(R.id.button2 );
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Upload.this, MainActivity.class);
                startActivity(i);
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (resultCode == RESULT_OK) {
            if (requestCode == CAMERA_REQUEST) {
                try {
                    camera_picture = (Bitmap) data.getExtras().get("data");

                    ContextWrapper cw = new ContextWrapper(getApplicationContext());
                    File directory = getBaseContext().getDir("imageDir", Context.MODE_PRIVATE);

                    baos = new ByteArrayOutputStream();
                    camera_picture.compress(Bitmap.CompressFormat.JPEG, 100, baos);

                    image.setImageBitmap(camera_picture);

                    fos.flush();
                    fos.close();


                } catch (Exception e) {
                    Log.d("Picture writing ", e.getMessage().toString());
                }

            }

        }
    }
}
